#include<iostream>
#include<vector>
#include<queue>
#include <climits>
#include <string> // NEW: Needed for reading "yes" or "no"

using namespace std;

// MODIFIED: Added a boolean 'isBroken' to store the state of the road.
struct AdjListNode{
    int vertex;
    int weight;
    bool isBroken;

    // MODIFIED: The constructor now accepts the broken status.
    AdjListNode(int vertex, int weight, bool isBroken){
        this->vertex = vertex;
        this->weight = weight;
        this->isBroken = isBroken;
    }
};

// MODIFIED: This function now prints the broken status of each road.
void printAdjList(const vector<vector<AdjListNode>>& adjListVector, int V){
    cout << "**************Adj List**************" << endl;
    for(int i = 1; i <= V; i++){
        // Example: "(6,15,not broken)"
        for(const AdjListNode& n : adjListVector[i]){
            cout << "(" << n.vertex << "," << n.weight << "," << (n.isBroken ? "broken" : "not broken") << ")";
        }
        cout << endl;
    }
    cout << "************************************" << endl;
}

// --- These parts are unchanged as they form the core of the algorithm ---

// Global arrays to store the MST result
int key[100];
int parent[100];
bool inMST[100];

// Node for the priority queue
struct PQNode{
    int vertex;
    int key;
    PQNode(int vertex, int key){
        this->vertex = vertex;
        this->key = key;
    }
};

// Comparator for the min-priority queue
struct Comparator{
    bool operator() (PQNode a, PQNode b){
        return a.key > b.key;
    }
};

// The core Prim's algorithm function (unchanged)
void Prims(const vector<vector<AdjListNode>>& adjListVector, int s, int V){
    for(int v = 1; v <= V; v++){
        key[v] = INT_MAX;
        parent[v] = -1;
        inMST[v] = false;
    }

    key[s] = 0;
    priority_queue<PQNode, vector<PQNode>, Comparator> pq;
    pq.push(PQNode(s, key[s]));

    while(!pq.empty()){
        PQNode n = pq.top();
        pq.pop();
        int u = n.vertex;

        if(inMST[u]){
            continue;
        }
        inMST[u] = true;

        for(const AdjListNode& adjListNode : adjListVector[u]){
            int v = adjListNode.vertex;
            int w = adjListNode.weight;
            if(!inMST[v] && key[v] > w){
                key[v] = w;
                parent[v] = u;
                pq.push(PQNode(v, key[v]));
            }
        }
    }
}

// NEW: Function to print the selected edges and calculate total road length.
// MODIFIED: This function now prints the output in the format "u --- v (w km)".
int printMSTAndCalcLength(int V, int startNode) {
    cout << "Selected edges:" << endl;
    int totalRoadLength = 0;
    for (int i = 1; i <= V; i++) {
        // Skip the starting node as it has no parent in the tree.
        if (i == startNode) {
            continue;
        }
        if (parent[i] != -1) {
            // Print parent, child, and the weight of the edge (key[i]).
            cout << parent[i] << " --- " << i << " (" << key[i] << " km)" << endl;
            totalRoadLength += key[i];
        }
    }
    return totalRoadLength;
}


int main(){
    vector<vector<AdjListNode>> adjListVector;
    int V, E;
    cout << "Enter the number of vertices and edges" << endl;
    cin >> V >> E;

    adjListVector.resize(V + 1);

    cout << "Enter the edges (source, destination, weight, broken [yes/no])" << endl;
    for(int i = 0; i < E; i++){
        int u, v, w;
        string brokenStr;
        cin >> u >> v >> w >> brokenStr;
        bool isBroken = (brokenStr == "yes");
        if (!isBroken) {
            adjListVector[u].push_back(AdjListNode(v, w, isBroken));
            adjListVector[v].push_back(AdjListNode(u, w, isBroken));
        }
    }

    printAdjList(adjListVector, V);

    int startNode = 1;
    Prims(adjListVector, startNode, V);

    int totalRoadLength = printMSTAndCalcLength(V, startNode);
    long long totalCost = (long long)totalRoadLength * 10000;

    // MODIFIED: Final output format adjusted to match the exam paper.
    cout << "Total road length = " << totalRoadLength << " km" << endl;
    cout << "Total cost = $" << totalCost << endl;

    return 0;
}


/*
Sample Input:
6 9
1 6 15 no
1 2 2 yes
1 4 10 no
2 3 2 no
2 4 1 no
3 4 20 no
3 6 6 no
4 5 6 no
5 6 10 no

Expected Output (like in exam paper):
Adj List ...
Selected edges:
2 --- 4 (1 km)
3 --- 2 (2 km)
1 --- 4 (10 km)
5 --- 4 (6 km)
6 --- 5 (10 km)
Total road length = 29 km
Total cost = $290000
*/