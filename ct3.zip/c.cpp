#include<iostream>
#include<vector>
#include<queue>
#include<climits>
using namespace std;

// Adjacency List Node
struct AdjListNode{
    int vertex;
    int weight;
    bool broken; // <-- added broken info
    AdjListNode(int vertex,int weight,bool broken){
        this->vertex = vertex;
        this->weight = weight;
        this->broken = broken;
    }
};

// Print adjacency list
void printAdjList(vector< vector<AdjListNode> > adjListVector, int V){
    cout<<"**************Adj List***************"<<endl;
    for(int i=1;i<=V;i++){
        for(AdjListNode n: adjListVector[i]){
            cout<<"("<<n.vertex<<","<<n.weight<<","<<(n.broken?"broken":"not broken")<<") ";
        }
        cout<<endl;
    }
    cout<<"**************Adj List***************"<<endl;
}

// Global arrays
int key[100];
int parent[100];
bool inMST[100];

// Node for priority queue
struct PQNode{
    int vertex;
    int key;
    PQNode(int vertex,int key){
        this->vertex = vertex;
        this->key = key;
    }
};

// Comparator for priority queue
struct Comparator{
    bool operator()(PQNode a, PQNode b){
        return a.key > b.key; // min-heap
    }
};

// Prim’s algorithm
void Prims(vector< vector<AdjListNode> > adjListVector,int s,int V,int E){
    for(int v=1;v<=V;v++){
        key[v] = INT_MAX;
        parent[v] = -1;
        inMST[v] = false;
    }

    key[s] = 0;
    priority_queue<PQNode, vector<PQNode>, Comparator> pq;
    pq.push(PQNode(s,key[s]));

    while(!pq.empty()){
        PQNode n = pq.top(); pq.pop();
        int u = n.vertex;

        if(inMST[u]) continue;
        inMST[u] = true;

        for(AdjListNode adjListNode: adjListVector[u]){
            int v = adjListNode.vertex;
            int w = adjListNode.weight;
            bool broken = adjListNode.broken;

            // ignore broken edges
            if(broken) continue;

            if(!inMST[v] && key[v] > w){
                key[v] = w;
                parent[v] = u;
                pq.push(PQNode(v,key[v]));
            }
        }
    }

    // Print selected edges
    cout<<"\n**************Selected edges***************"<<endl;
    int totalLength = 0;
    for(int v=2; v<=V; v++){
        if(parent[v] != -1){
            cout<<v<<" --- "<<parent[v]<<" ("<<key[v]<<" km)"<<endl;
            totalLength += key[v];
        }
    }
    cout<<"Total road length = "<<totalLength<<endl;
    cout<<"Total cost = $"<<(totalLength*10000)<<endl;
}

int main(){
    vector< vector<AdjListNode> > adjListVector;
    int V,E;
    cout<<"Enter the number of vertices and edges"<<endl;
    cin>>V>>E;

    for(int i=0;i<=V;i++){
        vector<AdjListNode> nodeVector;
        adjListVector.push_back(nodeVector);
    }

    cout<<"Enter the edges (source, destination, weight, broken[yes/no])"<<endl;
    for(int i=1;i<=E;i++){
        int u,v,w; string brokenStr;
        cin>>u>>v>>w>>brokenStr;
        bool broken = (brokenStr=="yes");
        AdjListNode n1(v,w,broken);
        AdjListNode n2(u,w,broken);
        adjListVector[u].push_back(n1);
        adjListVector[v].push_back(n2);
    }

    printAdjList(adjListVector,V);
    Prims(adjListVector,1,V,E);

    return 0;
}
/*
Sample Input:
6 9
1 6 15 no
1 2 2 yes
1 4 10 no
2 3 2 no
2 4 1 no
3 4 20 no
3 6 6 no
4 5 6 no
5 6 10 no

Expected Output (like in exam paper):
Adj List ...
Selected edges:
2 --- 4 (1 km)
3 --- 2 (2 km)
1 --- 4 (10 km)
5 --- 4 (6 km)
6 --- 5 (10 km)
Total road length = 29 km
Total cost = $290000
*/