#include<iostream>
#include<vector>
#include<queue>
#include <climits>
using namespace std;

// Modified adjacency list node to include broken status
struct AdjListNode{
    int vertex;
    int weight;
    string brokenStatus;  // "yes" or "no"
    AdjListNode(int vertex, int weight, string brokenStatus){
        this->vertex = vertex;
        this->weight = weight;
        this->brokenStatus = brokenStatus;
    }
};

// Function to print adjacency list with broken status
void printAdjList(vector<vector<AdjListNode>> adjListVector, int V){
    cout << "......Adj List**********" << endl;
    for(int i = 1; i <= V; i++){
        for(AdjListNode n : adjListVector[i]){
            cout << "(" << n.vertex << "," << n.weight << ",";
            if(n.brokenStatus == "yes") 
                cout << "broken) ";
            else 
                cout << "not broken) ";
        }
        cout << endl;
    }
    cout << "*************Adj List**********" << endl;
}

// Global arrays for Prim's algorithm
int key[100];
int parent[100];
bool inMST[100];

// Priority Queue node structure
struct PQNode{
    int vertex;
    int key;
    PQNode(int vertex, int key){
        this->vertex = vertex;
        this->key = key;
    }
};

// Comparator class for min-heap (smallest key first)
struct Comparator{
    bool operator() (PQNode a, PQNode b){
        return a.key > b.key;  // For min-heap
    }
};

// Modified Prim's algorithm that ignores broken roads
void Prims(vector<vector<AdjListNode>> adjListVector, int s, int V, int E){
    // Initialize arrays
    for(int v = 1; v <= V; v++){
        key[v] = INT_MAX;    // Infinite distance initially
        parent[v] = -1;      // No parent
        inMST[v] = false;    // Not in MST yet
    }

    key[s] = 0;  // Start from vertex 1 with key 0
    
    // Create priority queue (min-heap)
    priority_queue<PQNode, vector<PQNode>, Comparator> pq;
    PQNode startNode(s, key[s]);
    pq.push(startNode);

    while(!pq.empty()){
        PQNode currentNode = pq.top();
        pq.pop();
        
        int u = currentNode.vertex;
        
        if(inMST[u]) continue;  // Skip if already in MST
        
        inMST[u] = true;  // Add to MST
        
        // Check all neighbors
        for(AdjListNode neighbor : adjListVector[u]){
            int v = neighbor.vertex;
            int w = neighbor.weight;
            string broken = neighbor.brokenStatus;
            
            // Skip broken roads and vertices already in MST
            if(broken == "yes" || inMST[v]) continue;
            
            // If we found a better connection
            if(key[v] > w){
                key[v] = w;
                parent[v] = u;
                PQNode newNode(v, key[v]);
                pq.push(newNode);
            }
        }
    }
}

// Function to print selected edges for metro rail
void printSelectedEdges(int V){
    cout << "\nSelected edges" << endl;
    
    // Print edges in the format: vertex -- weight -- parent
    // Start from vertex 2 since vertex 1 has no parent
    for(int v = 2; v <= V; v++){
        if(parent[v] != -1){  // If vertex has a parent (is connected)
            cout << v << " —" << key[v] << "— " << parent[v] << endl;
        }
    }
}

// Function to calculate total cost
void calculateTotalCost(int V){
    int totalLength = 0;
    
    // Sum all keys except the starting vertex
    for(int v = 2; v <= V; v++){
        if(parent[v] != -1){
            totalLength += key[v];
        }
    }
    
    int totalCost = totalLength * 10000;  // $10,000 per km
    
    cout << "\nTotal road length = " << totalLength << endl;
    cout << "Total cost = $" << totalCost << endl;
}

int main(){
    vector<vector<AdjListNode>> adjListVector;
    int V, E;
    
    cout << "Enter the number of vertices and edges" << endl;
    cin >> V >> E;
    
    // Initialize adjacency list (index 0 unused, vertices from 1 to V)
    for(int i = 0; i <= V; i++){
        vector<AdjListNode> nodeVector;
        adjListVector.push_back(nodeVector);
    }
    
    cout << "Enter the edges (source, destination, weight, broken [yes/no])" << endl;
    // Read all edges with broken status
    for(int i = 1; i <= E; i++){
        int u, v, w;
        string broken;
        cin >> u >> v >> w >> broken;
        
        // Add edge in both directions (undirected graph)
        AdjListNode n1(v, w, broken);
        AdjListNode n2(u, w, broken);
        adjListVector[u].push_back(n1);
        adjListVector[v].push_back(n2);
    }
    
    // Print adjacency list
    printAdjList(adjListVector, V);
    
    // Run Prim's algorithm starting from vertex 1
    Prims(adjListVector, 1, V, E);
    
    // Print results
    printSelectedEdges(V);
    calculateTotalCost(V);
    
    return 0;
}